//
//  Comment.swift
//  Instagram
//
//  Created by Makarestov Hristo on 1.11.24.
//

import Foundation

struct Comment {
    let commentId: String
    let postId: String
    let userId: String
    let text: String
    let likes: [String]?
    let createdAt: TimeInterval
    let updatedAt: TimeInterval
    let user: User
    
    init(postId: String, userId: String, text: String, likes: [String]?, createdAt: TimeInterval, updatedAt: TimeInterval, user: User) {
        self.commentId = UUID().uuidString
        self.postId = postId
        self.userId = userId
        self.text = text
        self.likes = likes
        self.createdAt = createdAt
        self.updatedAt = updatedAt
        self.user = user
    }
    
    init(dictionary: [String: Any], user: User) {
        self.commentId = dictionary["commentId"] as? String ?? ""
        self.postId = dictionary["postId"] as? String ?? ""
        self.userId = dictionary["userId"] as? String ?? ""
        self.text = dictionary["text"] as? String ?? ""
        self.likes = dictionary["likes"] as? [String] ?? []
        self.createdAt = dictionary["createdAt"] as! TimeInterval
        self.updatedAt = dictionary["updatedAt"] as! TimeInterval
        self.user = user
    }
    
    init() {
        self.commentId = ""
        self.postId = ""
        self.userId = ""
        self.text = ""
        self.likes = []
        self.createdAt = 0
        self.updatedAt = 0
        self.user = User()
    }
}
