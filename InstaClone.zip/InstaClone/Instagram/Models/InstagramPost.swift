//
//  Post.swift
//  Instagram
//
//  Created by Makarestov Hristo on 18.09.24.
//

import Foundation

struct InstagramPostWrapper {
    let id: String
    let post: InstagramPost
}

struct InstagramPost {
    let postId: String
    let userId: String
    var imageUrl: String
    let caption: String
//    TODO: Convert to Comments struct
    var comments: [Comment]?
    let createdAt: TimeInterval
    let updatedAt: TimeInterval
    
    init(userId: String, imageUrl: String, caption: String, comments: [Comment], createdAt: TimeInterval, updatedAt: TimeInterval) {
        self.postId = UUID().uuidString
        self.userId = userId
        self.imageUrl = imageUrl
        self.caption = caption
        self.comments = comments
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
    
    init(dictionary: [String: Any]) {
        self.postId = dictionary["postID"] as? String ?? ""
        self.userId = dictionary["userID"] as? String ?? ""
        self.imageUrl = dictionary["imageURL"] as? String ?? ""
        self.caption = dictionary["caption"] as! String
        self.comments = dictionary["comments"] as? [Comment]
        self.createdAt = dictionary["createdAt"] as! TimeInterval
        self.updatedAt = dictionary["updatedAt"] as! TimeInterval
    }
    
    init() {
        self.postId = ""
        self.userId = ""
        self.imageUrl = ""
        self.caption = ""
        self.comments = []
        self.createdAt = 0
        self.updatedAt = 0
    }
}
