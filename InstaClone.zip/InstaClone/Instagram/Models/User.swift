//
//  user.swift
//  Instagram
//
//  Created by Makarestov Hristo on 18.09.24.
//

import Foundation
import FirebaseAuth

struct User {
    let userId: String
    var username: String
    var fullName: String
    let email: String
    var profileImageUrl: URL?
    var bio: String
    var followersList: [String]
    var followingList: [String]
//    TODO: Make Let instead of Var
    var posts: [InstagramPost]
    let createdAt: TimeInterval
    let updatedAt: TimeInterval
    
    init(username: String, fullName: String, email: String, profileImageUrl: URL, bio: String, followersList: [String], followingList: [String], posts: [InstagramPost], createdAt: TimeInterval, updatedAt: TimeInterval) {
        self.userId = Auth.auth().getUserID() ?? ""
        self.username = username
        self.fullName = fullName
        self.email = email
        self.profileImageUrl = profileImageUrl
        self.bio = bio
        self.followersList = followersList
        self.followingList = followingList
        self.posts = posts
        self.createdAt = createdAt
        self.updatedAt = updatedAt
    }
    
    init() {
        self.userId = ""
        self.username = ""
        self.fullName = ""
        self.email = ""
        self.profileImageUrl = nil
        self.bio = ""
        self.followersList = []
        self.followingList = []
        self.posts = []
        self.createdAt = 0
        self.updatedAt = 0
    }
    
    init(dictionary: [String: Any]) {
        let urlString = dictionary["profileImageUrl"] as? String ?? ""
        self.userId = dictionary["userID"] as? String ?? ""
        self.username =  dictionary["username"] as? String ?? ""
        self.fullName = dictionary["fullName"] as? String ?? ""
        self.email = dictionary["email"] as? String ?? ""
        self.profileImageUrl = URL(string: urlString)
        self.bio = dictionary["bio"] as? String ?? ""
        self.followersList = dictionary["followersList"] as? [String] ?? []
        self.followingList = dictionary["followingList"] as? [String] ?? []
        self.posts = dictionary["posts"] as? [InstagramPost] ?? []
        self.createdAt = dictionary["createdAt"] as? TimeInterval ?? 0
        self.updatedAt = dictionary["updatedAt"] as? TimeInterval ?? 0
    }
}
