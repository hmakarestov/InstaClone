//
//  UIViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 9.09.24.
//

import UIKit

protocol ReusableIdentifier {
    static var reusableIdentifier: String { get }
}

extension UIViewController {
    func hideKeyboardWhenTappedAround() {
        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        tap.cancelsTouchesInView = false
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func registerForKeyboardNotifications() {
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    func unregisterForKeyboardNotifications() {
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    @objc func keyboardWillShow(notification: NSNotification) {
        guard let userInfo = notification.userInfo,
              let keyboardFrame = userInfo[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else { return }
        
        let keyboardHeight = keyboardFrame.height
        adjustForKeyboard(keyboardHeight: keyboardHeight)
    }
    
    @objc func keyboardWillHide(notification: NSNotification) {
        adjustForKeyboard(keyboardHeight: 0)
    }

    private func adjustForKeyboard( keyboardHeight: CGFloat) {
        if let activeTextField = view.firstResponder as? UITextField {
            let textFieldFrameInView = activeTextField.convert(activeTextField.bounds, to: view)
            let textFieldBottomY = textFieldFrameInView.origin.y + textFieldFrameInView.size.height
            
            let viewHeight = view.frame.height
            let keyboardY = viewHeight - keyboardHeight
            if keyboardHeight > 0 && textFieldBottomY > keyboardY {
                UIView.animate(withDuration: LocalConstants.viewAnimationDiration) { [weak self] in
                    self?.view.frame.origin.y = -(textFieldBottomY-keyboardY)
                }
            } else {
                UIView.animate(withDuration: LocalConstants.viewAnimationDiration) { [weak self] in
                    self?.view.frame.origin.y = 0
                }
            }
        }
    }
    private struct LocalConstants {
        static let viewAnimationDiration: Double = 0.3
    }
}

extension UIViewController: ReusableIdentifier {
    static var reusableIdentifier: String {
      return String(describing: Self.self)
  }
//    TODO: add Auth.auth()
}

extension UIView {
    var firstResponder: UIResponder? {
        if self.isFirstResponder {
            return self
        }
        for subview in self.subviews {
            if let firstResponder = subview.firstResponder {
                return firstResponder
            }
        }
        return nil
    }
}
