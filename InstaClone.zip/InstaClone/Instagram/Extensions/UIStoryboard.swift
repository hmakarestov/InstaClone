//
//  UIStoryboard.swift
//  ChangeX
//
//  Created by Nikolay Kovachev on 8.03.22.
//

import UIKit

extension UIStoryboard {
    static var main: UIStoryboard {
        return UIStoryboard.init(name: "Main", bundle: nil)
    }

    static var home: UIStoryboard {
        return UIStoryboard.init(name: "Home", bundle: nil)
    }
    
    static var profile: UIStoryboard {
        return UIStoryboard.init(name: "Profile", bundle: nil)
    }
}
