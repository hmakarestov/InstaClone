//
//  UserDefaults.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import Foundation

final class UserDefaultsData {
    static var loggedUserId: String {
        get {
            return UserDefaults.standard.string(forKey: "loggedUserId") ?? ""
        }
        set {
            UserDefaults.standard.setValue(newValue, forKey: "loggedUserId")
            UserDefaults.standard.synchronize()
        }
    }
    
//    static var isLoggedIn: Bool {
//        get {
//            return UserDefaults.standard.bool(forKey: "isLoggedIn")
//        }
//        set {
//            UserDefaults.standard.setValue(newValue, forKey: "isLoggedIn")
//            UserDefaults.standard.synchronize()
//        }
//    }
    
//    static var uploadPictureUrl: String {
//        get {
//            return UserDefaults.standard.string(forKey: "uploadPictureUrl") ?? ""
//        }
//        set {
//            UserDefaults.standard.setValue(newValue, forKey: "uploadPictureUrl")
//            UserDefaults.standard.synchronize()
//        }
//    }
}
