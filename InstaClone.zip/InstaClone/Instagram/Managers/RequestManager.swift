//
//  RequestManager.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import Foundation
import UIKit
import FirebaseAuth
import FirebaseStorage
import FirebaseDatabaseInternal
import Kingfisher

final class RequestManager {
    static let shared = RequestManager()
    private let storage = Storage.storage().reference()
    private var ref: DatabaseReference = Database.database().reference()
    
    func getImageByURL(imageUrl: URL, completion: @escaping (UIImage?) -> Void) {
        let storageRef = Storage.storage().reference(forURL: imageUrl.absoluteString)
        storageRef.downloadURL(completion: { (url, error) in
            
            do {
                let data = try Data(contentsOf: url!)
                let image = UIImage(data: data)
                completion(image)
                
            } catch {
                print(error.localizedDescription)
                completion(nil)
            }
            
        })
    }
    
    func createUser(email: String, password: String, completion: @escaping(_ success: Bool?,_ error: Error?) -> Void ) {
        Auth.auth().createUser(withEmail: email, password: password) { authResult, error in
            guard let _ =  authResult?.user, error == nil else {
                completion(nil, error)
                print("Error \(String(describing: error?.localizedDescription))")
                return
            }
            completion(true, nil)
        }
    }
    
    func loginUser(email: String, password: String, completion: @escaping(_ success: Bool?,_ error: Error?) -> Void ) {
        Auth.auth().signIn(withEmail: email, password: password) { authResult, error in
            guard let _ = authResult?.user, error == nil else {
                fatalError(String(describing: error?.localizedDescription))
            }
            
            UserDefaultsData.loggedUserId = Auth.auth().getUserID() ?? ""
            completion(true, nil)
        }
    }
    
    func uploadImage(image: UIImage, completion: @escaping (URL?) -> Void) {
        guard let imageData = image.pngData() else { return }
        guard let userId = Auth.auth().getUserID() else { return }
        
        storage.child("images").child(userId).child("\(userId).png").putData(imageData,
                                                                             metadata: nil,
                                                                             completion: { _ , error in
            guard error == nil else {
                return
            }
            self.storage.child("images").child(userId).child("\(userId).png").downloadURL(completion: { url, error in
                guard let url = url, error == nil else { return }
                completion(url)
            })
        })
    }
    
    func createPost(post: InstagramPost) {
        ref.child(LocalConstants.postsChildIdentifier)
            .child(post.postId)
            .setValue([
                "postID": post.postId,
                "userID": post.userId,
                "imageURL": post.imageUrl,
                "caption": post.caption,
                "comments": post.comments ?? [],
                "createdAt": post.createdAt,
                "updatedAt": post.updatedAt
            ])
    }
    
    func createUser(user: User) {
        ref.child(LocalConstants.usersChildIdentifier)
            .child(user.userId)
            .setValue([
                "userID": user.userId,
                "username": user.username,
                "fullName": user.fullName,
                "email": user.email,
                "profileImageUrl": user.profileImageUrl?.absoluteString ?? "",
                "bio": user.bio,
                "followersList": user.followersList,
                "followingList": user.followingList,
                "posts": user.posts,
                "createdAt": Date.now.timeIntervalSince1970,
                "updatedAt": Date.now.timeIntervalSince1970
            ])
    }
    
    func createComment(comment: Comment) {
        ref.child(LocalConstants.commentsChildIdentifier)
            .child(comment.postId).child(comment.commentId)
            .setValue([
                "commentId": comment.commentId,
                "postId": comment.postId,
                "userId": comment.userId,
                "text": comment.text,
                "createdAt": Date.now.timeIntervalSince1970,
                "updatedAt": Date.now.timeIntervalSince1970
            ])
    }
    
    func getAllPosts(completion: @escaping ([InstagramPost]?) -> Void) {
        ref.child(LocalConstants.postsChildIdentifier).observeSingleEvent(of: .value, with: { snapshot in
            guard let dictionaries = snapshot.value as? [String: Any] else { return }
            var posts: [InstagramPost] = []
            dictionaries.forEach { (key,value) in
                guard let postDictionary = value as? [String: Any] else { return }
                let post = InstagramPost(dictionary: postDictionary)
                posts.append(post)
            }
            completion(posts)
        }) { error in
            completion(nil)
        }
    }
    
    func getAllUsers(completion: @escaping ([User]?) -> Void) {
        ref.child(LocalConstants.usersChildIdentifier).observeSingleEvent(of: .value, with: { snapshot in
            guard let dictionaries = snapshot.value as? [String: Any] else { return }
            var users: [User] = []
            dictionaries.forEach { (key,value) in
                guard let userDictionary = value as? [String: Any] else { return }
                let user = User(dictionary: userDictionary)
                users.append(user)
            }
            completion(users)
        }) { error in
            completion(nil)
        }
    }
    
    func followUser(user: User) {
        ref.child(LocalConstants.usersChildIdentifier)
            .child(user.userId).updateChildValues(["followingList": user.followingList])
    }
    
    func getFollowedByUser(user: User) {
        ref.child(LocalConstants.usersChildIdentifier)
            .child(user.userId).updateChildValues(["followersList": user.followersList])
    }
    
    func getCurrentUser(completion: @escaping (User?) -> Void) {
        getUserById(userId: Auth.auth().getUserID() ?? "") { user in
            completion(user)
        }
    }
    
    func getUserById(userId: String, completion: @escaping (User?) -> Void) {
        ref.child(LocalConstants.usersChildIdentifier).child(userId).observeSingleEvent(of: .value, with: { snapshot in
            let userDictionary = snapshot.value as? [String: Any] ?? [:]
            let user = User(dictionary: userDictionary)
            completion(user)
        }) { error in
            completion(nil)
        }
    }
    
    func getAllCommentsById(postId: String, completion: @escaping ([Comment]?) -> Void) {
        ref.child(LocalConstants.commentsChildIdentifier).child(postId).observeSingleEvent(of: .value, with: { snapshot in
            guard let dictionaries = snapshot.value as? [String: Any] else {
                completion(nil)
                return
            }
            var allComments: [Comment] = []
            let dispatchGroup: DispatchGroup = DispatchGroup()
            dictionaries.forEach { (key,value) in
                guard let commentDictionary = value as? [String: Any] else {
                    completion(nil)
                    return
                }
                let userId = commentDictionary[LocalConstants.userId] as? String ?? ""
                dispatchGroup.enter()
                self.getUserById(userId: userId) { user in
                    guard let user = user else {
                        completion(nil)
                        dispatchGroup.leave()
                        return
                    }
                    let comment = Comment(dictionary: commentDictionary, user: user)
                    allComments.append(comment)
                    dispatchGroup.leave()
                }
            }
            dispatchGroup.notify(queue: .main) {
                completion(allComments)
            }
        }) { error in
            completion(nil)
        }
    }
    
    func updateUser(user: User) {
        ref.child(LocalConstants.usersChildIdentifier)
            .child(user.userId).updateChildValues([
                "profileImageUrl": user.profileImageUrl?.absoluteString ?? "",
                "username": user.username,
                "fullName": user.fullName,
                "email": user.email,
                "bio": user.bio,
                "updatedAt": Date.now.timeIntervalSince1970
            ])
    }
    
    func updateComments(post: InstagramPost) {
        ref.child(LocalConstants.postsChildIdentifier)
            .child(post.postId).updateChildValues([
                "comments": post.comments ?? []
            ])
    }
    
    private struct LocalConstants {
        static let postsChildIdentifier: String = "posts"
        static let usersChildIdentifier: String = "users"
        static let commentsChildIdentifier: String = "comments"
        static let userId: String = "userId"
    }
}
