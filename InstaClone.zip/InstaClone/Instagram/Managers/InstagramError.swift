//
//  InstagramError.swift
//  Instagram
//
//  Created by Makarestov Hristo on 3.10.24.
//

import Foundation

enum InstagramError: String, Error {
    case invalidEmailOrPassword = "Email is invalid"
    case noEmailFilled = "No Email filled"
    
    var description: String {
        self.rawValue
    }
}
