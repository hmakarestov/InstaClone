//
//  ContainerViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import UIKit
import FirebaseAuth

final class ContainerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let userId = UserDefaultsData.loggedUserId
        if userId == "" {
            performSegue(withIdentifier: Constants.loginSegue, sender: nil)
            
        } else{
            performSegue(withIdentifier: Constants.homeSegue, sender: nil)
        }
    }
    
    private enum Constants {
        static let loginSegue: String = "fromContainerToLoginSegue"
        static let homeSegue: String = "fromContainerToTabBarControllerSegue"
    }
}
