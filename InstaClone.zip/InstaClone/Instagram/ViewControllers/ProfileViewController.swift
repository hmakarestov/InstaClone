//
//  PostViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 11.09.24.
//

import UIKit
import FirebaseDatabaseInternal

class ProfileViewController: UIViewController {

    @IBOutlet weak var uuidTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!

    private var ref: DatabaseReference = Database.database().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    private func uploadPost() {
        let id = UUID().uuidString
        ref.child("users")
            .child("id\(id)")
            .setValue([
                "randomUUID": uuidTextField.text,
                "name": nameTextField.text,
                "email": emailTextField.text,
            ])
    }
    
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        uploadPost()
    }
}
