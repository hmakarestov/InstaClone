//
//  HomeViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import Foundation
import UIKit
import FirebaseStorage
import FirebaseAuth

final class HomeViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {
    
    @IBOutlet weak var imageView: UIImageView!
    private let picker = UIImagePickerController()
    
    private let storage = Storage.storage().reference()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
        picker.allowsEditing = true
    }
    
    @IBAction func uploadPictureTapped(_ sender: UIButton) {
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }

    @IBAction func takePhotoTapped(_ sender: UIButton) {
        picker.sourceType = .camera
        picker.cameraDevice = .rear
        picker.showsCameraControls = true
        present(picker, animated: true)
    }
    
    @IBAction func logOutTapped(_ sender: UIButton) {
        let auth = Auth.auth()
        
        do {
            try auth.signOut()
            UserDefaultsData.loggedUserId = ""
            self.dismiss(animated: true, completion: nil)
        } catch let logOutError {
            print(logOutError.localizedDescription)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else { return }
        guard let imageData = image.pngData() else { return }
        
        let id = UUID().uuidString
        
        storage.child("images/\(id).png").putData(imageData,
                                                 metadata: nil,
                                                 completion: { _, error in
            guard error == nil else {
                print("Failed to upload")
                return
            }

            self.storage.child("images/\(id).png").downloadURL(completion: {url, error in
                guard let url = url, error == nil else { return }
                let urlString = url.absoluteString
                print("Download URL: \(urlString)")
                //UserDefaultsData.uploadPictureUrl = urlString
                self.imageView.image = image
            })
        })
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func createPostTapped(_ sender: UIButton) {
        guard let profileCOntroller  = UIStoryboard.main.instantiateViewController(
            withIdentifier: ProfileViewController.reusableIdentifier
        ) as? ProfileViewController else {
            fatalError("Could not find VC")
        }
        
        self.navigationController?.pushViewController(profileCOntroller, animated: true)
    }
}
