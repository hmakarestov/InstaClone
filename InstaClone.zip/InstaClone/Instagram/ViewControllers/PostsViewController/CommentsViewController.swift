//
//  CommentsTableViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 30.10.24.
//

import UIKit

class CommentsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UINavigationControllerDelegate {
    
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var addCommentTextField: UITextField!
    @IBOutlet private weak var addCommentButton: UIButton!
    
    private var viewModel = CommentsViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        self.registerForKeyboardNotifications() // place in will appear and will disappear
    }
    
    func setViewModel(vm: CommentsViewModel) {
        self.viewModel = vm
    }
    // MARK: - Table view data source

    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.getCommentsCount()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: LocalConstants.commentTableViewCell, for: indexPath) as? CommentTableViewCell else {
            fatalError("Could not find cell")
        }
        let comment = viewModel.getComments()[indexPath.row] // get comment by indexPath
        cell.setupCell(comment: comment)
        return cell
    }
    
    
    @IBAction func didTapAddCommentButton(_ sender: UIButton) {
        guard let commentText = addCommentTextField.text else { return }
        viewModel.uploadComment(text: commentText)
        addCommentTextField.text = ""
        tableView.reloadData()
    }
    
    private struct LocalConstants {
        static let commentTableViewCell: String = "commentTableViewCell"
    }
}
