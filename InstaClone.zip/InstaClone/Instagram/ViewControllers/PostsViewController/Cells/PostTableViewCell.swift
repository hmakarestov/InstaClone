//
//  PostTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 11.09.24.
//

import UIKit
import SVProgressHUD
import Kingfisher
import FirebaseAuth

protocol PostTableViewCellDelegate {
    func didTapLikeButton(from cell: PostTableViewCell, isLiked: Bool, for row: Int)
    func didTapCommentButton(from cell: PostTableViewCell, for row: Int)
    func didTapShareButton(from cell: PostTableViewCell, for row: Int)
}

final class PostTableViewCell: UITableViewCell {

    @IBOutlet weak var mainStackView: UIStackView!
    @IBOutlet weak var headerStackView: UIStackView!
    @IBOutlet weak var postImageView: UIImageView!
    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var imagesStackView: UIStackView!
    @IBOutlet weak var likeButton: UIButton!
    @IBOutlet weak var commentButton: UIButton!
    @IBOutlet weak var shareButton: UIButton!
    
    private var isLiked: Bool = false
    private var row: Int = 0
    private var post: InstagramPost?
    private var userId = ""
    var delegate: PostTableViewCellDelegate?
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    func setupCell(post: InstagramPost, and row: Int) {
        let url = URL(string: post.imageUrl)
        profileImageView.kf.setImage(with: url)
        userNameLabel.text = post.userId
        changeHeartButtonImage()
        postImageView.kf.setImage(with: url)
        selectionStyle = .none
        self.row = row
        self.post = post
        userId = Auth.auth().getUserID() ?? ""
    }
    
    private func changeHeartButtonImage() {
        
        let heartImageName = isLiked ? LocalConstants.selectedLikeButtonImage : LocalConstants.unselectedLikeButtonImage
        likeButton.setImage(UIImage(systemName: heartImageName), for: .normal)
    }
    
    @IBAction func didTapLike(_ sender: UIButton) {
        changeHeartButtonImage()
    }
    
    @IBAction func didTapCommentButton(_ sender: UIButton) {
        delegate?.didTapCommentButton(from: self, for: row)
    }
    
    @IBAction func didTapShareButton(_ sender: UIButton) {
        delegate?.didTapShareButton(from: self, for: row)
    }
    
    private struct LocalConstants {
        static let selectedLikeButtonImage: String = "heart.fill"
        static let unselectedLikeButtonImage: String = "heart"
    }
}
