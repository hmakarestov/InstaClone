//
//  CommentTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 30.10.24.
//

import UIKit
import Kingfisher

class CommentTableViewCell: UITableViewCell {

    @IBOutlet private weak var userProfileImageView: UIImageView!
    @IBOutlet private weak var usernameLabel: UILabel!
    @IBOutlet private weak var timeSinceUploadLabel: UILabel!
    @IBOutlet private weak var commentLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func setupCell(comment: Comment) {
        userProfileImageView.kf.setImage(with: comment.user.profileImageUrl)
        usernameLabel.text = comment.user.username
        timeSinceUploadLabel.text = comment.createdAt.description
        commentLabel.text = comment.text
    }
}
