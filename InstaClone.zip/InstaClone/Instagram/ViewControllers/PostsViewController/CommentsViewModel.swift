//
//  CommentsViewModel.swift
//  Instagram
//
//  Created by Makarestov Hristo on 30.10.24.
//

import Foundation
import FirebaseAuth

struct UserDetails {
    let profilePictureUrl: String
    let username: String
}

class CommentsViewModel {
    
    private var postId = ""
    private var comments: [Comment] = []
    
    func setPost(postId: String) {
        self.postId = postId
    }
    
    func setComments(completion: ((_ success: Bool?, _ error: String?)-> Void)? = nil) {
        RequestManager.shared.getAllCommentsById(postId: postId) { [weak self] results in
            self?.comments = results ?? []
            completion?(true, nil)
        }
    }
    
    func getCommentsCount() -> Int {
        return comments.count
    }
    
    func getComments() -> [Comment] {
        return comments
    }
    
    func uploadComment(text: String) {
        guard let currentUserId = Auth.auth().getUserID() else { return }
        RequestManager.shared.getCurrentUser { [weak self] user in
            guard let user = user else { return }
            let comment: Comment = Comment(
                postId: self?.postId ?? "",
                userId: currentUserId,
                text: text, likes: [],
                createdAt: Date.now.timeIntervalSince1970,
                updatedAt: Date.now.timeIntervalSince1970,
                user: user
            )
            self?.comments.append(comment)
            RequestManager.shared.createComment(comment: comment)
        }
    }
}
