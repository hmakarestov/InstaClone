//
//  PostsTableTableViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 11.09.24.
//

import UIKit
import SVProgressHUD

final class PostsTableTableViewController: UITableViewController {

    private var posts: [InstagramPost] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateData()
    }

    func populateData() {
        RequestManager.shared.getAllPosts { result in
            guard let posts = result else { return }
            self.posts = posts
            DispatchQueue.main.async { [weak self] in
                self?.tableView.reloadData()
            }
        }
    }
    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return posts.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: LocalConstants.postTableViewCell, for: indexPath) as? PostTableViewCell else {
            fatalError("Could not find cell")
        }
        
        cell.setupCell(post: posts[indexPath.row], and: indexPath.row)
        cell.selectionStyle = .none
        cell.delegate = self
        return cell
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return tableView.frame.width + 68
    }
    
    private struct LocalConstants {
        static let postTableViewCell: String = "PostTableViewCell"
        static let timeDelay: Double = 2
    }
}

extension PostsTableTableViewController: PostTableViewCellDelegate {
    func didTapShareButton(from cell: PostTableViewCell, for row: Int) {
        SVProgressHUD.show(withStatus: "Did tap on share button at row: \(row)")
        DispatchQueue.main.asyncAfter(deadline: .now() + 3, execute: {
            SVProgressHUD.dismiss()
        })
    }
    
    func didTapCommentButton(from cell: PostTableViewCell, for row: Int) {
        guard let vc = self.storyboard?.instantiateViewController(withIdentifier: CommentsViewController.reusableIdentifier)
                as? CommentsViewController else { return }
        let vm = CommentsViewModel()
        vm.setPost(postId: posts[row].postId)
        vm.setComments { success, error in
            if let success = success, success {
                vc.setViewModel(vm: vm)
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
    }
    
    func didTapLikeButton(from cell: PostTableViewCell, isLiked: Bool, for row: Int) {
        DispatchQueue.main.async { [weak self] in
            self?.tableView.reloadData()
        }
    }
}
