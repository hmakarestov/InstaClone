//
//  LogInViewModel.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import Foundation
import FirebaseAuth

class LogInViewModel {
    private var email: String?
    private var password: String?
    
    func setupEmail(from emailText: String?) {
        email = emailText
    }
    
    func setupPassword(from passwordText: String?) {
        password = passwordText
    }
    
    func logIn(completion: @escaping(_ success: Bool?,_ error: InstagramError?) -> Void) {
        guard let email = email, email != "" else {
            completion(nil, InstagramError.noEmailFilled)
            return
        }
        
        guard let password = password, password != "" else {
            completion(nil, InstagramError.invalidEmailOrPassword)
            return
        }
        
        RequestManager.shared.loginUser(email: email, password: password) { success,error in
            if let success = success, success {
                completion(true, nil)
            } else {
                completion(nil, InstagramError.invalidEmailOrPassword)
            }
        }
    }
}
