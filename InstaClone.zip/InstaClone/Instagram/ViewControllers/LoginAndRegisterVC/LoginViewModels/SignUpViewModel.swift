//
//  SignUpViewModel.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import Foundation

final class SignUpViewModel {
    private var email: String?
    private var password: String?
    private var confirmPassword: String?
    
    func setupEmail(from emailText: String?) {
        email = emailText
    }
    
    func setupPassword(from passwordText: String?) {
        password = passwordText
    }
    
    func setupConfirmPassword(from confirmPasswordText: String?) {
        confirmPassword = confirmPasswordText
    }
    
    func signUpUser(completion: @escaping(_ success: Bool?,_ error: InstagramError?) -> Void) {
        guard let email = email, email != "" else {
            completion(nil, InstagramError.noEmailFilled)
            return
        }
        
        guard let password = password,
              let confirmPassword = confirmPassword,
              password != "",
              confirmPassword != "",
              password == confirmPassword else {
            completion(nil, InstagramError.invalidEmailOrPassword)
            return
        }
        
        RequestManager.shared.createUser(email: email, password: password) { success, error in
            if let success = success, success {
                completion(true, nil)
            } else {
                completion(nil, InstagramError.invalidEmailOrPassword)
            }
        }
    }
}
