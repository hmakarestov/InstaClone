//
//  SignUpViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 28.08.24.
//

import Foundation
import UIKit
import Firebase
import FirebaseAuth

final class SignUpViewController: UIViewController {
    
    @IBOutlet weak private var emailTextField: UITextField!
    @IBOutlet weak private var passwordTextField: UITextField!
    @IBOutlet weak private var confirmPasswordTextField: UITextField!
    
    private let viewModel = SignUpViewModel()
    private let loginViewModel = LogInViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
    }
    
    
    @IBAction private func didTapSignUp(_ sender: UIButton) {
        signUp()
    }
    
    @IBAction private func didTapLogIn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    private func signUp() {
        viewModel.setupEmail(from: emailTextField.text)
        viewModel.setupPassword(from: passwordTextField.text)
        viewModel.setupConfirmPassword(from: confirmPasswordTextField.text)
        
        viewModel.signUpUser { success, error in
            if let success = success, success {
                self.loginViewModel.setupEmail(from: self.emailTextField.text)
                self.loginViewModel.setupPassword(from: self.passwordTextField.text)
                
                self.loginViewModel.logIn { success,error in
                    DispatchQueue.main.async { [weak self] in
                        guard let email = self?.emailTextField.text else { return }
                        let user = User(username: "",
                                        fullName: "",
                                        email: email,
                                        profileImageUrl: URL(fileURLWithPath: ""),
                                        bio: "",
                                        followersList: [],
                                        followingList: [],
                                        posts: [],
                                        createdAt: Date.now.timeIntervalSince1970,
                                        updatedAt: Date.now.timeIntervalSince1970)
                        RequestManager.shared.createUser(user: user)
                        guard let viewCotnroller = UIStoryboard.main.instantiateViewController(withIdentifier: UITabBarController.reusableIdentifier) as? UITabBarController else { return }
                        self?.navigationController?.pushViewController(viewCotnroller, animated: true)
                    }
                }
            }
            
            if let error = error {
                print(error.description)
            }
        }
    }
}
