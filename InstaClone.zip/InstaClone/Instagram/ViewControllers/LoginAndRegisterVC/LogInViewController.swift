//
//  ViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 27.08.24.
//

import UIKit
import FirebaseAuth

final class LogInViewController: UIViewController {
    
    @IBOutlet weak private var emailTextField: UITextField!
    @IBOutlet weak private var passwordTextField: UITextField!
    @IBOutlet weak private var forgottenPassword: UILabel!
    
    private let viewModel = LogInViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.isHidden = true
        self.hideKeyboardWhenTappedAround()
    }
    
    @IBAction private func didTapLogIn(_ sender: UIButton) {
        logIn()
    }
    
    @IBAction private func didTapSignUp(_ sender: UIButton) {
        guard let viewCotnroller = UIStoryboard.main.instantiateViewController(withIdentifier: SignUpViewController.reusableIdentifier) as? SignUpViewController else { return }
        navigationController?.pushViewController(viewCotnroller, animated: true)
    }
    
    private func logIn() {
        viewModel.setupEmail(from:  emailTextField.text)
        viewModel.setupPassword(from: passwordTextField.text)
        
        viewModel.logIn { success,error in
            if let success = success, success {
                DispatchQueue.main.async { [weak self] in
                    guard let viewCotnroller = UIStoryboard.main.instantiateViewController(
                        withIdentifier: UITabBarController.reusableIdentifier) as? UITabBarController else { return }
                    self?.navigationController?.pushViewController(viewCotnroller, animated: true)
                }
            }
            
            if let error = error {
                fatalError(error.description)
            }
        }
    }
}

