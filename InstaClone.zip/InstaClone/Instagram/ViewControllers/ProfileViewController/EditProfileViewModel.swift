//
//  EditProfileViewModel.swift
//  Instagram
//
//  Created by Makarestov Hristo on 23.10.24.
//

import Foundation
import UIKit

class EditProfileViewModel {
    private var user: User = User()
    private var newProfileImage: UIImage? = nil
    lazy var editProfileArray: [EditProfileRow] = [
        EditProfileRow(type: .image, value: user.profileImageUrl?.absoluteString ?? ""),
        EditProfileRow(type: .fullName, value: user.fullName),
        EditProfileRow(type: .username, value: user.username),
        EditProfileRow(type: .bio, value: user.bio),
        EditProfileRow(type: .save, value: EditProfileRow.RowType.save.rawValue)
    ]
    
    func setUser(user: User) {
        self.user = user
    }
    
    func setUserFullName(name: String) {
        user.fullName = name
    }
    
    func setUserUsername(name: String) {
        user.username = name
    }
    
    func setUserBio(bio: String) {
        user.bio = bio
    }
    
    func setNewProfileImage(image: UIImage) {
        newProfileImage = image
    }
    
    func getUser() -> User {
        return user
    }
    
    func getNewProfileImage() -> UIImage {
        guard let newProfileImage = newProfileImage else { return UIImage()}
        return newProfileImage
    }
    
    func uploadProfilePhotoToRTDB() {
        guard let newProfileImage = newProfileImage else {
            RequestManager.shared.updateUser(user: self.user)
            return
        }
        RequestManager.shared.uploadImage(image: newProfileImage) { [weak self] result in
            guard let result = result,
            let strongSelf = self
            else { return }
            strongSelf.user.profileImageUrl = result
            RequestManager.shared.updateUser(user: strongSelf.user)
        }
    }
}
