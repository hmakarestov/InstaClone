//
//  EditProfileViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.10.24.
//

import UIKit

struct EditProfileRow {
    enum RowType: String, CaseIterable {
        case image = ""
        case fullName = "Full Name"
        case username = "Username"
        case bio = "Bio"
        case save = "Save"
    }
    
    let type: RowType
    let value: String
}

protocol EditViewControllerDelegate {
    func didTapSaveButton(from viewController: EditProfileViewController)
}

class EditProfileViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    private let picker = UIImagePickerController()
    var delegate: EditViewControllerDelegate?
    private let viewModel = EditProfileViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        
        picker.delegate = self
        picker.allowsEditing = true
    }
    
    func configureUser(user: User) {
        viewModel.setUser(user: user)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.editProfileArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let row = viewModel.editProfileArray[indexPath.row]
        
        switch row.type {
        case .image:
            guard let cell = tableView.dequeueReusableCell(
                withIdentifier: LocalConstants.profileImageCellIdentifier,
                for: indexPath) as? ProfileImageTableViewCell else {
                fatalError("Cell not found")
            }
            if viewModel.getNewProfileImage() != UIImage() {
                cell.setupCell(image: viewModel.getNewProfileImage())
            } else {
                guard let url = URL(string: row.value) else { return UITableViewCell() }
                RequestManager.shared.getImageByURL(imageUrl: url) { image in
                    cell.setupCell(image: image)
                }
            }
            return cell
        case .fullName, .username:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: LocalConstants.textFieldCellIdentifier, for: indexPath) as? TextFieldTableViewCell else {
                fatalError("Cell not found")
            }
            cell.setupCell(placeholder: row.type.rawValue, value: row.value)
            cell.returnString = { [weak self] text in
                switch row.type {
                case .fullName:
                    self?.viewModel.setUserFullName(name: text)
                case .username:
                    self?.viewModel.setUserUsername(name: text)
                default:
                    return
                }
            }
            return cell
        case .bio:
            guard let cell = tableView.dequeueReusableCell(
                withIdentifier: LocalConstants.biotextViewCellIdentifier,
                for: indexPath) as? BioTextViewTableViewCell else {
                fatalError("Cell not found")
            }
            cell.setupCell(value: row.value)
            cell.returnString = { [weak self] text in
                self?.viewModel.setUserBio(bio: text)
            }
            return cell
        case .save:
            guard let cell = tableView.dequeueReusableCell(
                withIdentifier: LocalConstants.saveButtonCellIdentifier,
                for: indexPath) as? SaveButtonTableViewCell else {
                fatalError("Cell not found")
            }
            cell.didTapButton = {
                self.viewModel.uploadProfilePhotoToRTDB()
                self.delegate?.didTapSaveButton(from: self)
            }
            return cell
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let rowtype = viewModel.editProfileArray[indexPath.row].type
        if rowtype == .image {
            picker.sourceType = .photoLibrary
            present(picker, animated: true)
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else { return }
        
        viewModel.setNewProfileImage(image: image)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
    
    private struct LocalConstants {
        static let profileImageCellIdentifier: String = "profileImageCellIdentifier"
        static let textFieldCellIdentifier: String = "textFieldCellIdentifier"
        static let biotextViewCellIdentifier: String = "bioTextViewCellIdentifier"
        static let saveButtonCellIdentifier: String = "saveButtonCellIdentifier"
    }
}
