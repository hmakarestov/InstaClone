//
//  ProfileCollectionViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.09.24.
//

import UIKit
import Kingfisher

final class ProfilePostCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet private weak var imageView: UIImageView!
    
    func configure(with imageURL: String) {
        if let url = URL(string: imageURL) {
            imageView.kf.setImage(with: url)
        }
    }
}
