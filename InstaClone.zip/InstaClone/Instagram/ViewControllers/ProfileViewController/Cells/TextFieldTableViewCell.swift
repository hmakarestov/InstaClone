//
//  TextFieldTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.10.24.
//

import UIKit

class TextFieldTableViewCell: UITableViewCell {

    @IBOutlet weak var textField: UITextField!
    var returnString: StringEvent?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func setupCell(placeholder: String, value: String) {
        textField.placeholder = placeholder
        textField.text = value
        textField.delegate = self
    }
}

extension TextFieldTableViewCell: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        returnString?(textField.text ?? "")
    }
}
