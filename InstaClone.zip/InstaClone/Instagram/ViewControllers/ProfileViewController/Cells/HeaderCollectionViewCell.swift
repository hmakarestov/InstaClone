//
//  HeaderCollectionViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.09.24.
//

import UIKit
import Kingfisher
import FirebaseAuth

protocol HeaderCollectionViewCellDelegate {
    func didTapFollowButton(from cell: HeaderCollectionViewCell)
    func didTapEditProfileButton(from cell: HeaderCollectionViewCell)
    func setFollowButtonStatus(from cell: HeaderCollectionViewCell)
    func setProfilePage(from cell: HeaderCollectionViewCell)
}

final class HeaderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet private weak var profilePicture: UIImageView!
    @IBOutlet private weak var postsLabel: UILabel!
    @IBOutlet private weak var nameLabel: UILabel!
    @IBOutlet private weak var bioLabel: UILabel!
    @IBOutlet private weak var postsNumber: UILabel!
    @IBOutlet private weak var followersLabel: UILabel!
    @IBOutlet private weak var followersNumber: UILabel!
    @IBOutlet private weak var followingLabel: UILabel!
    @IBOutlet private weak var followingNumber: UILabel!
    @IBOutlet private weak var followButton: UIButton!
    @IBOutlet private weak var editProfileButton: UIButton!
    
    private var user = User()
    var delegate: HeaderCollectionViewCellDelegate?
    
    func configure(user: User, postsCount: Int) {
        self.user = user
        if let profileImageUrl = user.profileImageUrl,
           profileImageUrl.absoluteString != "file:///" {
            profilePicture.kf.setImage(with: user.profileImageUrl)
        }
        
        delegate?.setFollowButtonStatus(from: self)
        
        postsLabel.text = LocalConstants.postsLabel
        followersLabel.text = LocalConstants.followersLabel
        followingLabel.text = LocalConstants.followingLabel
        
        postsNumber.text = String(postsCount)
        followersNumber.text = String(user.followersList.count)
        followingNumber.text = String(user.followingList.count)
        
        nameLabel.text = user.username
        bioLabel.text = user.bio
        
        delegate?.setProfilePage(from: self)
    }
    
    func showEditProfileButton() {
        editProfileButton.isHidden = false
    }
    
    func showFollowButton() {
        followButton.isHidden = false
    }
    
    func hideEditProfileButton() {
        editProfileButton.isHidden = true
    }
    
    func hideFollowButton() {
        followButton.isHidden = true
    }

    
    func switchToUnfollowButton() {
//        followButton.backgroundColor = UIColor(.gray)
        followButton.setTitle("Unfollow", for: .normal)//titleLabel?.text = "Unfollow"
    }
    
    func switchToFollowButton() {
//        followButton.backgroundColor = UIColor(.blue)
        followButton.setTitle("Follow", for: .normal)//.titleLabel?.text = "Follow"
    }
    
    @IBAction func didTapFollowButton(_ sender: UIButton) {
        delegate?.didTapFollowButton(from: self)
    }
    
    @IBAction func didTapEditProfileButton(_ sender: UIButton) {
        delegate?.didTapEditProfileButton(from: self)
    }
    
    private struct LocalConstants {
        static let postsLabel = "Posts"
        static let followersLabel = "Followers"
        static let followingLabel = "Following"
    }
}
