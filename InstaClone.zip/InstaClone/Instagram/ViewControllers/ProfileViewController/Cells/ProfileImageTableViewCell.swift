//
//  ProfileImageTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.10.24.
//

import UIKit


class ProfileImageTableViewCell: UITableViewCell {

    @IBOutlet weak private var profileImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    func setupCell(image: UIImage?) {
        guard let image = image else { return }
        profileImageView.image = image
    }
}
