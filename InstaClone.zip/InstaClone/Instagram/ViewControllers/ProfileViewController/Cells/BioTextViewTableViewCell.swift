//
//  TextViewTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.10.24.
//

import UIKit

class BioTextViewTableViewCell: UITableViewCell {

    @IBOutlet weak var textView: UITextView!
    var returnString: StringEvent?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setupCell(value: String) {
        textView.text = value
        textView.delegate = self
    }
}

extension BioTextViewTableViewCell: UITextViewDelegate {
    func textViewDidEndEditing(_ textView: UITextView) {
        returnString?(textView.text ?? "")
    }
}
