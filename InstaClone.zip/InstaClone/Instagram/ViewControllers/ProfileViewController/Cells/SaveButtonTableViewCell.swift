//
//  SaveButtonTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 16.10.24.
//

import UIKit

class SaveButtonTableViewCell: UITableViewCell {

    @IBOutlet weak var saveButton: UIButton!
    var didTapButton: Event?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    
    @IBAction func didTapSaveButton(_ sender: UIButton) {
        didTapButton?()
    }
}
