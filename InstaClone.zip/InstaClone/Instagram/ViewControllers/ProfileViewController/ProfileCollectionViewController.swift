//
//  ProfileCollectionViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 13.09.24.
//

import UIKit
import FirebaseAuth

final class ProfileCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    private var viewModel = ProfileViewModel()
    var isCurrentProfilePageShown: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if isCurrentProfilePageShown {
            viewModel.getCurrentUser()
            DispatchQueue.main.async {
                self.configure(vm: self.viewModel)
            }
        }
    }

    func setViewModel(vm: ProfileViewModel) {
        self.viewModel = vm
        configure(vm: vm)
    }
    
    func configure(vm: ProfileViewModel) {
        vm.populateData { success, error in
            if success == true && error == nil {
                DispatchQueue.main.async { [weak self] in
                    self?.navigationItem.title = vm.getUser().email
                    self?.collectionView.reloadData()
                    self?.collectionView.layoutIfNeeded()
                    self?.collectionView.reloadData()
                }
            }
        }
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }


    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return viewModel.getPostsCount() + LocalConstants.itemsCountAdjustment
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let index = indexPath.item
        
        if index == 0 {
            guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LocalConstants.headerCellIdentifier, for: indexPath) as? HeaderCollectionViewCell else { return UICollectionViewCell() }
            cell.configure(user: viewModel.getUser(), postsCount: viewModel.getPostsCount())
            cell.delegate = self
            
            return cell
        }

        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LocalConstants.profileCellIdentifier, for: indexPath) as? ProfilePostCollectionViewCell else { return UICollectionViewCell() }
        cell.configure(with: viewModel.getPostImageUrlByIndex(index: index - LocalConstants.itemsCountAdjustment))
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width
        if indexPath.item > 0 {
            let height = (width - 9.0) / 3
            return CGSize(width: height, height: height)
        }
        
        let headerHeight = LocalConstants.headerCellHeight + calculateHeight(in: viewModel.getUserBio())
        return CGSize(width: width, height: headerHeight)
    }
    
    private func calculateHeight(in string:String) -> CGFloat {
        let attributes : [NSAttributedString.Key : Any] = [
            NSAttributedString.Key(
                rawValue: NSAttributedString.Key.font.rawValue)
            : UIFont.systemFont(ofSize: LocalConstants.bioFontSize
            )
        ]
        let attributedString : NSAttributedString = NSAttributedString(string: string, attributes: attributes)
        let rect : CGRect = attributedString.boundingRect(with: CGSize(width: view.frame.width - LocalConstants.constraintSize, height: CGFloat.greatestFiniteMagnitude),
                                                          options: .usesLineFragmentOrigin, context: nil)
        let requredSize:CGRect = rect
        return requredSize.height
    }

    private struct LocalConstants {
        static let profileCellIdentifier = "ProfilePostCollectionViewCell"
        static let headerCellIdentifier = "HeaderCell"
        static let headerCellHeight: Double = 110
        static let bioFontSize: Double = 17.0
        static let constraintSize: CGFloat = 32
        static let itemsCountAdjustment: Int = 1
    }
}

extension ProfileCollectionViewController: HeaderCollectionViewCellDelegate {
    func setProfilePage(from cell: HeaderCollectionViewCell) {
        if viewModel.isCurrentUserProfilePage() == true {
            cell.hideFollowButton()
            cell.showEditProfileButton()
        } else {
            cell.showFollowButton()
            cell.hideEditProfileButton()
        }
    }
    
    func setFollowButtonStatus(from cell: HeaderCollectionViewCell) {
        RequestManager.shared.getCurrentUser { [weak self] user in
            guard let user = user else { return }
            if user.followingList.contains(self?.viewModel.getUserId() ?? "") {
                cell.switchToUnfollowButton()
            } else {
                cell.switchToFollowButton()
            }
        }
    }
    
    func didTapEditProfileButton(from cell: HeaderCollectionViewCell) {
        guard let editProfileVC = self.storyboard?.instantiateViewController(withIdentifier: EditProfileViewController.reusableIdentifier) as? EditProfileViewController else { return }
        editProfileVC.configureUser(user: viewModel.getUser())
        editProfileVC.delegate = self
        self.present(editProfileVC, animated: true)
    }
    
    func didTapFollowButton(from cell: HeaderCollectionViewCell) {
        viewModel.followUser { success, error in
            if let success = success, success {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [weak self] in
                    self?.collectionView.reloadData()
                }
            } else {
                fatalError(error?.localizedDescription ?? "")
            }
        }
    }
}

extension ProfileCollectionViewController: EditViewControllerDelegate {
    func didTapSaveButton(from viewController: EditProfileViewController) {
        DispatchQueue.main.async { [weak self] in
            viewController.dismiss(animated: true)
            self?.viewModel.getCurrentUser()
        }
    }
}
