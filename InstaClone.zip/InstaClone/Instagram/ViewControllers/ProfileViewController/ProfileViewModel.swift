//
//  ProfileViewModel.swift
//  Instagram
//
//  Created by Makarestov Hristo on 23.10.24.
//

import Foundation
import FirebaseAuth

class ProfileViewModel {
    
    private var user = User()
    private var posts: [InstagramPost] = []
    
    func populateData(completion: @escaping(_ success: Bool?,_ error: Error?) -> Void ) {
        var userPosts: [InstagramPost] = []
        
        RequestManager.shared.getAllPosts { result in
            guard let posts = result else { return }
            for post in posts where post.userId == self.user.userId {
                userPosts.append(post)
            }
            self.setPosts(posts: userPosts)
            completion(true, nil)
        }
    }
    
    func followUser(completion: @escaping(_ success: Bool?,_ error: Error?) -> Void ) {
        RequestManager.shared.getUserById(userId: Auth.auth().getUserID() ?? "") { [weak self] user in
            guard var user = user, let strongSelf = self else { return }
            var profileUser = strongSelf.getUser()
            
            if user.followingList.contains(strongSelf.getUserId()) {
                if let index = user.followingList.firstIndex(of: profileUser.userId) {
                    user.followingList.remove(at: index)
                }
                
                if let index = profileUser.followersList.firstIndex(of: user.userId) {
                    profileUser.followersList.remove(at: index)
                }
                RequestManager.shared.followUser(user: user)
                RequestManager.shared.getFollowedByUser(user: profileUser)
            } else {
                user.followingList.append(profileUser.userId)
                profileUser.followersList.append(user.userId)
                RequestManager.shared.followUser(user: user) // add followed user to list
                RequestManager.shared.getFollowedByUser(user: profileUser) // add follower to list
            }

            RequestManager.shared.getUserById(userId: profileUser.userId) { [weak self] currentOpenedProfile in
                guard let currentOpenedProfile = currentOpenedProfile else { return }
                self?.user = currentOpenedProfile
                completion(true, nil)
            }
        }
    }
    
    // MARK: - Posts Functions
    
    func setPosts(posts: [InstagramPost]) {
        self.posts = posts
    }
    
    func getPosts() -> [InstagramPost] {
        return posts
    }
    
    func getPostsCount() -> Int {
        return posts.count
    }
    
    func getPostImageUrlByIndex(index: Int) -> String {
        return posts[index].imageUrl
    }
    
    // MARK: - Users Functions
    
    func setUser(user: User) {
        self.user = user
    }
    
    func getUser() -> User {
        return user
    }
    
    func getUserId() -> String {
        return user.userId
    }
    
    func getUserBio() -> String {
        return user.bio
    }
    
    func getCurrentUser() {
        guard let currentUserId = Auth.auth().getUserID() else { return }
        RequestManager.shared.getUserById(userId: currentUserId) { [weak self] user in
            guard let user = user else { return }
            self?.setUser(user: user)
        }
    }
    
    func isCurrentUserProfilePage() -> Bool {
        if user.userId == Auth.auth().getUserID() {
            return true
        }
        return false
    }
}
