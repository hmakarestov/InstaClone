//
//  UploadPhotoCollectionViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 20.09.24.
//

import UIKit

final class UploadPhotoCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak private var imageView: UIImageView!
    
    func configure(with image: UIImage?) {
        imageView.image = image
    }
}
