//
//  CheckoutPostViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 25.09.24.
//

import UIKit
import FirebaseAuth

final class CheckoutPostViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var descriptionTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
    }
    
    func configure(with image: UIImage) {
        imageView.image = image
    }
    
    @IBAction func didTapCloseButton(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func didTapPostButton(_ sender: UIBarButtonItem) {
        guard let image = imageView.image else { return }
        guard let userIdString = Auth.auth().getUserID() else { return }

        RequestManager.shared.uploadImage(image: image) { result in
            guard let result = result else { return }
            let post = InstagramPost(userId: userIdString,
                                     imageUrl: result.absoluteString,
                                     caption: self.descriptionTextView.text,
                                     comments: [],
                                     createdAt: Date.now.timeIntervalSince1970,
                                     updatedAt: Date.now.timeIntervalSince1970)
            RequestManager.shared.createPost(post: post)
        }

        self.presentingViewController?.presentingViewController?.dismiss(animated: true, completion: nil)
    }
}
