//
//  UploadPostCollectionViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 19.09.24.
//

import UIKit
import Photos

final class UploadPostCollectionViewController: UICollectionViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UICollectionViewDelegateFlowLayout {

    private let picker = UIImagePickerController()

    private var imageArray: [UIImage] = []
    private var assetsArray: [PHAsset] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
        picker.allowsEditing = true
        populatePhotos()
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = (view.frame.width - 9) / 3
        return CGSize(width: size, height: size)
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LocalConstants.uploadReuseIdentifier, for: indexPath) 
                as? UploadPhotoCollectionViewCell else { return UICollectionViewCell() }

        cell.configure(with: imageArray[indexPath.item])
        return cell
    }
    
    @IBAction func didTapCloseButton(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func didTapCameraButton(_ sender: UIBarButtonItem) {
        picker.sourceType = .camera
        picker.cameraDevice = .rear
        picker.showsCameraControls = true
        present(picker, animated: true)
    }
    
    private func presentCheckoutPost(with image: UIImage) {
        let checkoutPostViewController = self.storyboard?.instantiateViewController(
            withIdentifier: CheckoutPostViewController.reusableIdentifier) as! CheckoutPostViewController
        checkoutPostViewController.loadViewIfNeeded()
        checkoutPostViewController.configure(with: image)
        present(checkoutPostViewController, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        picker.dismiss(animated: true)
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else { return }
        presentCheckoutPost(with: image)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true)
    }
    
    private func populatePhotos() {
        PHPhotoLibrary.requestAuthorization { [weak self] status in
            if status == .authorized {
                let assets = PHAsset.fetchAssets(with: PHAssetMediaType.image, options: nil)
                assets.enumerateObjects { (object,_,_) in
                    self?.assetsArray.append(object)
                }
                self?.assetsArray.reverse()
                self?.convertAssetsToImages(assets: self?.assetsArray ?? [])
                DispatchQueue.main.async {
                    self?.collectionView.reloadData()
                }
            }
        }
    }
    
    private func convertAssetsToImages(assets: [PHAsset]) {
        let manager = PHImageManager.default()
        for asset in assets {
            manager.requestImage(for: asset,
//                               TODO: fix target size
                                 targetSize: CGSize(width: 1000, height: 1000),
                                 contentMode: .aspectFill,
                                 options: nil) { image, _ in
                DispatchQueue.main.async {
                    guard let image = image else { return }
                    self.imageArray.append(image)
                }
            }
        }
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        presentCheckoutPost(with: imageArray[indexPath.item])
    }
    
    private struct LocalConstants {
        static let uploadReuseIdentifier = "UploadPostCollectionViewCell"
    }
}
