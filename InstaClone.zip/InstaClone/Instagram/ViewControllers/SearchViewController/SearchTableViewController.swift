//
//  SearchTableViewController.swift
//  Instagram
//
//  Created by Makarestov Hristo on 8.10.24.
//

import UIKit

class SearchTableViewController: UITableViewController, UISearchControllerDelegate {

    private var users: [User] = []
    private var filteredUsers: [User] = []
    private var searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        configureSearchBar()
        getUsers()
    }

    private func getUsers() {
        RequestManager.shared.getAllUsers { users in
            guard let usersArray = users else { return }
            self.users = usersArray
            DispatchQueue.main.async { [weak self] in
                self?.tableView.reloadData()
            }
        }
    }
    
    @IBAction func didTapBackButton(_ sender: UIBarButtonItem) {
        self.dismiss(animated: true, completion: nil)
    }
    
    private func configureSearchBar() {
        searchController.searchResultsUpdater = self
        searchController.obscuresBackgroundDuringPresentation = false
        definesPresentationContext = false
        navigationItem.hidesSearchBarWhenScrolling = false
        navigationItem.searchController = searchController
        searchController.delegate = self
    }
    
    // MARK: - Table view data source
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return filteredUsers.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "searchTableViewCellIdentifier", for: indexPath) as? SearchTableViewCell else {
            fatalError("Could not find cell")
        }
        cell.configure(user: filteredUsers[indexPath.row])
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let profileVC = UIStoryboard.profile.instantiateViewController(
            withIdentifier: ProfileCollectionViewController.reusableIdentifier) as? ProfileCollectionViewController else { return }
        let viewModel = ProfileViewModel()
        viewModel.setUser(user: filteredUsers[indexPath.row])
//        profileVC.setUser(user: filteredUsers[indexPath.row])
        profileVC.setViewModel(vm: viewModel)
        profileVC.isCurrentProfilePageShown = false
        profileVC.loadViewIfNeeded()
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(profileVC, animated: true)
        }
    }
    
    private func containsElement(input: String) {
        filteredUsers = users.filter({$0.email.contains(input.lowercased())})
    }
}

extension SearchTableViewController: UISearchResultsUpdating {
    func updateSearchResults(for searchController: UISearchController) {
        guard let searchBarText = searchController.searchBar.text else { return }
        containsElement(input: searchBarText)
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
}
