//
//  SearchTableViewCell.swift
//  Instagram
//
//  Created by Makarestov Hristo on 8.10.24.
//

import UIKit
import Kingfisher

class SearchTableViewCell: UITableViewCell {

    @IBOutlet weak var profileImageView: UIImageView!
    @IBOutlet weak var usernameLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configure(user: User) {
//        profileImageView.kf.setImage(with: user.profileImageUrl)
        profileImageView.image = UIImage(systemName: "person.circle.fill")
        usernameLabel.text = user.email
    }
}
